-- Creiamo il nuovo database se non esiste
CREATE DATABASE IF NOT EXISTS ToysGroupDB;

-- Selezioniamo il database appena creato per eseguire i comandi successivi al suo interno
USE ToysGroupDB;

-- Tabella Regions
CREATE TABLE IF NOT EXISTS Regions (
  RegionID INT AUTO_INCREMENT,  -- Chiave primaria auto-incrementante per l'identificativo univoco della regione
  RegionName VARCHAR(250) NOT NULL,  -- Nome della regione, non può essere nullo
  CONSTRAINT PK_Regions PRIMARY KEY (RegionID)  -- Definizione del vincolo di chiave primaria
);

-- Tabella Categories
CREATE TABLE IF NOT EXISTS Categories (
  CategoryID INT AUTO_INCREMENT,  -- Chiave primaria auto-incrementante per l'identificativo univoco della categoria
  CategoryName VARCHAR(250) NOT NULL,  -- Nome della categoria, non può essere nullo
  CategoryDescription TEXT,  -- Descrizione opzionale della categoria
  CONSTRAINT PK_Categories PRIMARY KEY (CategoryID)  -- Definizione del vincolo di chiave primaria
);

-- Tabella States
CREATE TABLE IF NOT EXISTS States (
  StateID INT AUTO_INCREMENT,  -- Chiave primaria auto-incrementante per l'identificativo univoco dello stato
  StateName VARCHAR(250) NOT NULL,  -- Nome dello stato, non può essere nullo
  RegionID INT,  -- Chiave esterna che fa riferimento alla tabella Regions
  CONSTRAINT PK_States PRIMARY KEY (StateID),  -- Definizione del vincolo di chiave primaria
  FOREIGN KEY (RegionID) REFERENCES Regions(RegionID)  -- Definizione del vincolo di chiave esterna verso Regions
);

-- Tabella Products
CREATE TABLE IF NOT EXISTS Products (
  ProductID INT AUTO_INCREMENT,  -- Chiave primaria auto-incrementante per l'identificativo univoco del prodotto
  ProductName VARCHAR(250) NOT NULL,  -- Nome del prodotto, non può essere nullo
  ProductDescription TEXT,  -- Descrizione opzionale del prodotto
  CategoryID INT,  -- Chiave esterna che fa riferimento alla tabella Categories
  CONSTRAINT PK_Products PRIMARY KEY (ProductID),  -- Definizione del vincolo di chiave primaria
  FOREIGN KEY (CategoryID) REFERENCES Categories(CategoryID)  -- Definizione del vincolo di chiave esterna verso Categories
);

-- Tabella Sales
CREATE TABLE IF NOT EXISTS Sales (
  SalesID INT AUTO_INCREMENT,  -- Chiave primaria auto-incrementante per l'identificativo univoco della vendita
  ProductID INT NOT NULL,  -- Chiave esterna che fa riferimento alla tabella Products (non può essere nullo)  
  QuantitySold INT NOT NULL,  -- Quantità di prodotto venduto, non può essere nulla
  UnitPrice DECIMAL(10, 2) NOT NULL,  -- Prezzo unitario del prodotto al momento della vendita, non può essere nullo
  StateID INT NOT NULL,  -- Chiave esterna che fa riferimento alla tabella States (non può essere nullo)
  SalesDate DATE NOT NULL,  -- Data della vendita, non può essere nulla
  CONSTRAINT PK_Sales PRIMARY KEY (SalesID),  -- Definizione del vincolo di chiave primaria
  FOREIGN KEY (ProductID) REFERENCES Products(ProductID),  -- Definizione del vincolo di chiave esterna verso Products
  FOREIGN KEY (StateID) REFERENCES States(StateID)  -- Definizione del vincolo di chiave esterna verso States
);

-- Cominciamo ad inserire i dati nelle tabelle

-- Popolamento tabella Regions
INSERT INTO Regions (RegionName) VALUES
('Scandinavia'),
('Balcani'),
('Caraibi'),
('Medio Oriente'),
('America Centrale');

-- Popolamento tabella Categories
INSERT INTO Categories (CategoryName, CategoryDescription) VALUES
('Action Figures', 'Personaggi in miniatura ispirati a film e fumetti'),
('Giochi da Tavolo', 'Giochi di strategia e intrattenimento'),
('Puzzle', 'Puzzle educativi e decorativi per tutte le età'),
('Bolle di Sapone', 'Set professionali per spettacoli e bambini'),
('Peluche', 'Animali morbidi e personaggi fantastici');

-- Popolamento tabella States
INSERT INTO States (StateName, RegionID) VALUES
('Svezia', 1),
('Norvegia', 1),
('Albania', 2),
('Serbia', 2),
('Barbados', 3),
('Cuba', 3),
('Iran', 4),
('Iraq', 4),
('Panama', 5),
('Guatemala', 5);

-- Popolamento tabella Products
INSERT INTO Products (ProductName, ProductDescription, CategoryID) VALUES
('Iron Man Mark 50', 'Action Figure Marvel alte prestazioni con luci', 1),
('Monopoly Classic', 'Il classico gioco di strategia immobiliare', 2),
('Puzzle Castello Neuschwanstein', '1000 pezzi per adulti', 3),
('Bubble Master 360', 'Macchina professionale per bolle giganti', 4),
('Orsetto Peluche Jumbo', 'Orsacchiotto morbido 80cm in cotone', 5),
('Capitano America Shield', 'Riproduzione in metallo con supporto', 1),
('Catan', 'Gioco di strategia con espansione marina', 2);

-- Popolamento tabella Sales
INSERT INTO Sales (ProductID, StateID, SalesDate, QuantitySold, UnitPrice) VALUES
(1, 1, '2023-03-15', 5, 24.99),
(6, 3, '2023-06-10', 3, 89.99),
(2, 5, '2022-11-20', 8, 35.50),
(2, 7, '2023-08-01', 2, 35.50),
(3, 6, '2023-02-28', 15, 19.99),
(4, 9, '2023-07-04', 20, 12.99),
(5, 2, '2023-12-15', 10, 39.99),
(7, 4, '2023-05-10', 7, 45.00),
(1, 8, '2023-09-22', 4, 24.99),
(4, 10, '2023-10-30', 12, 12.99);


-- 1)	Verificare che i campi definiti come PK siano univoci. In altre parole, scrivi una query per determinare l’univocità dei valori di ciascuna PK (una query per tabella implementata).
SELECT COUNT(*) AS TotalRecords, COUNT(DISTINCT RegionID) AS UniqueRecords FROM Regions;		-- Tabella Regions
SELECT COUNT(*) AS TotalRecords, COUNT(DISTINCT CategoryID) AS UniqueRecords FROM Categories;	-- Tabella Categories
SELECT COUNT(*) AS TotalRecords, COUNT(DISTINCT StateID) AS UniqueRecords FROM States;			-- Tabella States
SELECT COUNT(*) AS TotalRecords, COUNT(DISTINCT ProductID) AS UniqueRecords FROM Products;		-- Tabella Products
SELECT COUNT(*) AS TotalRecords, COUNT(DISTINCT SalesID) AS UniqueRecords FROM Sales;			-- Tabella Sales

-- 2)	Esporre l’elenco delle transazioni indicando nel result set il codice documento, la data, il nome del prodotto, la categoria del prodotto, il nome dello stato, il nome della regione di vendita e un campo booleano valorizzato in base alla condizione che siano passati più di 180 giorni dalla data vendita o meno (>180 -> True, <= 180 -> False)
-- In questo caso sono tutti superiori ai 180 giorni
SELECT
    s.SalesID AS SalesID,
    s.SalesDate AS SalesDate,
    p.ProductName AS ProductName,
    c.CategoryName AS CategoryName,
    st.StateName AS StateName,
    r.RegionName AS RegionName,
    DATEDIFF('2025-04-11', s.SalesDate) > 180 AS Over180Days
FROM Sales as s
INNER JOIN Products as p ON s.ProductID = p.ProductID
INNER JOIN Categories as c ON p.CategoryID = c.CategoryID
INNER JOIN States as st ON s.StateID = st.StateID
INNER JOIN Regions as r ON st.RegionID = r.RegionID;

-- 3)	Esporre l’elenco dei prodotti che hanno venduto, in totale, una quantità maggiore della media delle vendite realizzate nell’ultimo anno censito. (ogni valore della condizione deve risultare da una query e non deve essere inserito a mano). Nel result set devono comparire solo il codice prodotto e il totale venduto.
SELECT
    p.ProductID,
    SUM(s.QuantitySold) AS TotalRevenue
FROM Sales as s
INNER JOIN Products AS P ON s.ProductID = p.ProductID
GROUP BY p.ProductID
HAVING SUM(s.QuantitySold) > (
    SELECT AVG(VenditeTotali)
    FROM (
        SELECT
            SUM(QuantitySold) AS VenditeTotali
        FROM Sales
        WHERE YEAR(SalesDate) = (SELECT MAX(YEAR(SalesDate)) FROM Sales)
        GROUP BY ProductID
    ) AS VenditeProdottiUltimoAnno
)
ORDER BY 2 DESC;

-- 4)	Esporre l’elenco dei soli prodotti venduti e per ognuno di questi il fatturato totale per anno.
SELECT
  P.ProductName,
  YEAR(S.SalesDate) AS SalesYear,
  SUM(S.QuantitySold * S.UnitPrice) AS TotalRevenue
FROM Sales AS S
INNER JOIN Products AS P ON S.ProductID = P.ProductID
GROUP BY P.ProductName, YEAR(S.SalesDate);

-- 5)	Esporre il fatturato totale per stato per anno. Ordina il risultato per data e per fatturato decrescente.
SELECT 
  st.StateName,
  YEAR(s.SalesDate) AS SalesYear,
  SUM(s.QuantitySold * s.UnitPrice) AS TotalRevenue
FROM Sales s
JOIN States AS st ON s.StateID = st.StateID
GROUP BY st.StateName, YEAR(s.SalesDate)
ORDER BY YEAR(s.SalesDate) DESC, TotalRevenue DESC;

-- 6)	Rispondere alla seguente domanda: qual è la categoria di articoli maggiormente richiesta dal mercato?
SELECT 
  C.CategoryName,
  SUM(S.QuantitySold) AS TotVenduto
FROM Sales AS S
INNER JOIN Products AS P ON S.ProductID = P.ProductID
INNER JOIN Categories AS C ON P.CategoryID = C.CategoryID
GROUP BY C.CategoryName
ORDER BY TotVenduto DESC;

-- 7)	Rispondere alla seguente domanda: quali sono i prodotti invenduti? Proponi due approcci risolutivi differenti.
-- Preciso che nel mio caso tutti i prodotti sono stati venduti
-- Primo Approccio con Left Join e filtriamo quelli senza corrispondenze
SELECT 
  P.ProductID,
  P.ProductName
FROM Products AS P
LEFT JOIN Sales AS S ON P.ProductID = S.ProductID
WHERE S.ProductID IS NULL;

-- Secondo Approccio con dove sommiamo le vendite ma teniamo solo quelli con NULL o 0
SELECT 
  P.ProductID,
  P.ProductName
FROM Products as P
LEFT JOIN Sales S ON P.ProductID = S.ProductID
GROUP BY P.ProductID, P.ProductName
HAVING SUM(S.QuantitySold) IS NULL OR SUM(S.QuantitySold) = 0;

-- 8)	Creare una vista sui prodotti in modo tale da esporre una “versione denormalizzata” delle informazioni utili (codice prodotto, nome prodotto, nome categoria)
SELECT 
  P.ProductID,
  P.ProductName,
  C.CategoryName
FROM Products AS P
INNER JOIN Categories C ON P.CategoryID = C.CategoryID;

-- 9)	Creare una vista per le informazioni geografiche
SELECT 
  S.StateID,
  S.StateName,
  R.RegionID,
  R.RegionName
FROM States AS S
JOIN Regions R ON S.RegionID = R.RegionID;




